using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.Diagnostics;

namespace AttributeAnalyzer
{
  public interface IAttributeAnalyzerAnalyzer
  {
  }

  [DiagnosticAnalyzer(LanguageNames.CSharp)]
  public class AttributeAnalyzerAnalyzer : DiagnosticAnalyzer, IAttributeAnalyzerAnalyzer
  {
    private static DiagnosticDescriptor ClassLevelAttributeDescriptor = new DiagnosticDescriptor(
        "SomeDiagnostic",
        "Found something:",
        "Attribute chain:\n {0}",
        "SomeCategory",
        DiagnosticSeverity.Warning,
        isEnabledByDefault: true,
        description: "Some description");

    public override ImmutableArray<DiagnosticDescriptor> SupportedDiagnostics => 
        ImmutableArray.Create(ClassLevelAttributeDescriptor);

    public override void Initialize(AnalysisContext context)
    {
      context.RegisterSymbolAction(AnylzeSymbolAttributes, SymbolKind.NamedType);
    }

    private static void AnylzeSymbolAttributes(SymbolAnalysisContext context)
    {
      var namedTypeSymbol = (INamedTypeSymbol)context.Symbol;
      
      var attributeNames = GetAttributeHierarchy(namedTypeSymbol, 0);
      context.ReportDiagnostic(Diagnostic.Create(ClassLevelAttributeDescriptor, namedTypeSymbol.Locations[0], string.Join("\n", attributeNames)));
    }

    private static IEnumerable<string> GetAttributeHierarchy(ISymbol typeSymbol, int depth)
    {
      if (depth > 4)
        yield break; // Poor man's cycle detection

      foreach (var attribute in typeSymbol.GetAttributes())
      {
        yield return new string(' ', depth * 3) + attribute.AttributeClass.MetadataName;

        if (attribute.AttributeConstructor == null)
        {
          yield return "Cannot recurse into '" + attribute.AttributeClass.MetadataName + "' (ctor=null)";
        }
        else
        {
          foreach (var attributeNames in GetAttributeHierarchy(attribute.AttributeConstructor.ContainingSymbol, depth + 1))
            yield return attributeNames;
        }
      }
    }
  }
}