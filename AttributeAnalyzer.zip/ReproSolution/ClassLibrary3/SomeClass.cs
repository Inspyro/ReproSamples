﻿using CommonLibrary;

namespace ClassLibrary3
{  
  [Some]
  public class SomeClass
  {
  }
}
