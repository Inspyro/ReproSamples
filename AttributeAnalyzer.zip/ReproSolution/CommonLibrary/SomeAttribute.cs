﻿using System;
using System.Runtime.Serialization;

namespace CommonLibrary
{
  [AttributeUsage(AttributeTargets.Class)]
  public class MyAttribute : Attribute
  {

  }

  [My]
  [DataContract]
  public class SomeAttribute : Attribute
  {

  }
}
